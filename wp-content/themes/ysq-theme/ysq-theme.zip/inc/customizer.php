<?php
/**
 * Theme Customizer
 *
 * @package YSQ
 */

if (!defined('ABSPATH')) {
    exit;
}

// Customizer functionality is already included in functions.php
// This file is kept for organizational purposes
